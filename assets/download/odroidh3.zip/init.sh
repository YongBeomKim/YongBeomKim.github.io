### Ubuntu INIT
## 1 kakao 로 Mirror 사이트 변경
sudo sed -i 's/kr.archive.ubuntu.com/mirror.kakao.com/g' /etc/apt/sources.list
sudo apt update && sudo apt upgrade
sudo apt-get install iputils-ping -y
sudo snap install nvim --classic

## 2 Reboot :: Start job is running for wait for network to be configured
# https://askubuntu.com/questions/972215/a-start-job-is-running-for-wait-for-network-to-be-configured-ubuntu-server-17-1
sudo systemctl disable systemd-networkd-wait-online.service
sudo systemctl mask systemd-networkd-wait-online.service
# ip addr

## 3 SSH
# SSH 접속지연발생시
# https://m.blog.naver.com/PostView.naver?isHttpsRedirect=true&blogId=webpioneer&logNo=221572167889
sudo apt install openssh-server -y
sudo apt install openssh-client
sudo systemctl status ssh
sudo ufw allow ssh
# sudo nvim /etc/ssh/sshd_config
## GSSAPIAuthentocation no (활성화)
# sudo service sshd restart
# ip a


## 4 FTP Server
# https://webnautes.tistory.com/1678
sudo apt-get install vsftpd
# sudo nvim /etc/vsftpd.conf
## listen=NO
## listen_ipv6=YES
## anonymous_enable=NO
## local_enable=YES
## chroot_local_user=YES
## allow_writeable_chroot=YES
## local_root=/data/ftp/files
## write_enable=YES
## local_umask=022
## dirmessage_enable=YES
## userlist_enable=YES
## userlist_file=/etc/vsftpd.userlist
## userlist_deny=NO
sudo systemctl restart vsftpd
sudo systemctl status vsftpd


### Odroid H3 WOL 설정
## https://wiki.odroid.com/odroid-h3/application_note/wake_on_lan
# Upgrade system packages
sudo apt update && sudo apt full-upgrade
# Install packages for build a module and working with WOL
sudo apt install build-essential libelf-dev ethtool

## Install the Ethernet Driver
# https://wiki.odroid.com/odroid-h3/hardware/install_ethernet_driver_on_h3plus
# https://www.realtek.com/en/component/zoo/category/network-interface-controllers-10-100-1000m-gigabit-ethernet-pci-express-software

