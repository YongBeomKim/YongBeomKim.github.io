from .base import *


# 크롤링 기본 Class
class Browser:

    r"""selenium crawler"""

    def __new__(cls, *args, **kwargs):
        r'''1. Create a new instance'''
        return super().__new__(cls)

    def __init__(self, display:bool = False):
        self.display = display
        self.window = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36"
        self.linux = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.96 Safari/537.36"
        self.mac = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4892.121 Safari/537.36"

    @property
    def browser(self):
        r"""Selenium Browser"""
        agents = [self.window, self.linux, self.mac]
        agent  = agents[randint(0,2)]
        options = webdriver.ChromeOptions()
        if self.display == False:
            options.headless = True
        options.add_argument("window-size=520,300")
        options.add_argument('disable-dev-shm-usage')
        options.add_argument("disable-gpu")
        options.add_argument("ignore-certificate-errors")
        options.add_argument("blink-settings=imagesEnabled=false")
        options.add_argument('no-sandbox')
        options.add_argument("lang=ko")
        options.add_argument(f'user-agent={agent}')
        browser = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
        return browser

    def requests(self, url:str="", headers:dict={}):
        agents = [self.window, self.linux, self.mac]
        agent  = agents[randint(0,2)]
        _headers = {
            'Host': urlparse(url).netloc,
            'User-Agent':agent,
            "Sec-Fetch-Dest":"document",
            "Sec-Fetch-Mode":"navigate",
            "Sec-Fetch-Site":"same-origin",
            "Accept-Language":"en-US,en;q=0.5",
            "Accept-Encoding":"gzip, deflate, br",
        }
        _headers.update(headers)
        return requests.get(url, headers=_headers)
