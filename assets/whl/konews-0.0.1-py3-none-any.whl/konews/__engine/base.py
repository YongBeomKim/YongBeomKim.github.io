# # Selenium WebDriver
# wget -nc https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
# sudo apt update 
# sudo apt install ./google-chrome-stable_current_amd64.deb
# pip install selenium webdriver-manager

# # Mouse Event Control 
# ! pip install pyperclip
# sudo apt-get install python3-tk python3-dev
import requests
from urllib.parse import urlparse
from random import randint
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
