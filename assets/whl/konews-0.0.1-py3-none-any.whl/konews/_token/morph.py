from .base import *


# 품사 재조정을 위한 클래스
class Morph:


    def __init__(self, path:str=None, worker=None):
        self.worker   = worker
        self.dic_path = path
        self.mecab = None
        if self.dic_path:
            self.mecab = Mecab(dicpath=self.dic_path)
        else:
            self.mecab = Mecab()
        # Mecab(dicpath='/home/buffet/Coding/venv/mecab-ko-dic-2.1.1-20180720')


    def _get_morphe(self, token):
        r"""품사태그 추가하기 by Mecab"""
        result = self.mecab.pos(token)
        return (token, result)


    def _token_index(self, tokens=None, mecab=False, items=None):

        r"""한글단어 Tag 추가 및 인덱싱 값 출력
        token : list => 작업 시작 tokens
        items : list(tuple) => mecab=True 작업 결과를 함수에 재입력"""
        if tokens:
            if self.worker:
                with multiprocessing.Pool(processes=self.worker) as pool:
                    items = list(tqdm(pool.imap(self._get_morphe, tokens)))
            else:
                items = list(self._get_morphe(_)  for _ in tqdm(tokens))

            # 명사태그 Index 추출 :1글자 이상 & 명사품사가 포함된 단어
            # _lambda = lambda x : x if x[1].find('NN') != -1 else None
            _lambda = lambda x : x if x[1] in ['NNG','NNP','NNB'] else None 
            if mecab:
                items = {
                    _[0]:_[1]  
                    for _ in items   
                    if ((len(_[0])>1) & (len(list(filter(_lambda, _[1])))>0))
                }
                return items

        # 외부에서 items 를 입력한 경우로 아랫 추가작업이 필요한 경우
        if items:
            items = items

        result  = {}
        for token, morph_tokens in tqdm(items):
            _lambda     = lambda x : x  if x[1] in ['NNG','NNP','NNB'] else None
            _morph_list = list(filter(_lambda, morph_tokens))
            _lambda     = lambda x :morph_tokens.index(x)
            _morph_idx  = list(map(_lambda, _morph_list))
            if len(_morph_idx) > 0:
                result[token] = _morph_idx
        return result


    def nouns_dict(self, texts):

        r"""명사태그 추출하기"""
        # Case 1
        # 마지막 단어에 명사가 포함된 경우
        print("*"*5," 마지막 단어에 명사가 포함 ","*"*5)
        tokens_raw = self._token_index(texts, mecab=True)
        tokens  = [(k,v)  for k,v in tokens_raw.items()]
        _lambda = lambda x : x if x[1][-1][1] in ['NNG','NNP','NNB'] != -1 else None
        tokens_dict = list(filter(_lambda, tqdm(tokens)))
        tokens_dict = {k:k   for k,_ in tokens_dict}

        # Case 2
        # 맨 앞 단어에 명사가 포함된 경우
        print("*"*5," 맨 앞 단어가 명사 ","*"*5)
        _lambda = lambda x : x  if x[0] not in list(tokens_dict.keys()) else None
        tokens  = list(filter(_lambda, tqdm(tokens)))
        _tokens_dict   = {_[0]:_[1]  for _ in tokens}
        _tokens_update = {
            k : _tokens_dict[k][0][0]   
            for k,v in tqdm(self._token_index(items=tokens).items())  
            if v == [0]
        }

        tokens_dict.update(_tokens_update)
        print(f"Updated counts : {len(_tokens_update):,}")

        # Case 3
        # 복합명사 (Noun Token 이 2개이상)
        print("*"*5," 복합명사에 해당되는 경우 ","*"*5)
        _lambda = lambda x : x  if x[0] not in list(tokens_dict.keys()) else None
        tokens  = list(filter(_lambda, tqdm(tokens)))
        _tokens_update = {}
        _tokens_idx    = self._token_index(items=tokens)

        for k,v in tqdm(_tokens_idx.items()):
            _idx   = v[-1]
            _token = _tokens_dict[k][:_idx+1]
            _tokens_update[k] = "".join(list(map(lambda x:x[0], _token)))

        tokens_dict.update(_tokens_update)
        print(f"Updated counts : {len(_tokens_update):,}")
        print(f"Noun collected : {len(tokens_dict):,}")
        return tokens_dict
