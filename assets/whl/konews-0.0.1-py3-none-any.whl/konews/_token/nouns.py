from .base import *


# Token 에서 명사 추출기
class Nouns:

    def __init__(self):
        pass

    def _test(self):
        pass

