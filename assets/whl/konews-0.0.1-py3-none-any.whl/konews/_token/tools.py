# Token 작업에 필요한 함수들 정리하기
from .news import NewsFilter
from .token import Token
from .base import *


# 뉴스 DataFrame 전처리 함수
def read_pkl(files, token, raw=False):

    r"""load pickle  & Pre Processing of DataFrame ..."""
    files  = [_  for _ in files  if _.find(token) != -1]
    df = [file_pickle(_, 'r') for _ in tqdm(files)]
    df = pandas.concat(df)
    if raw:
        return df
    print(f"Loading : {df.shape[0]:,}")

    # Pre Processing ...
    tokenClass = Token()
    newsF      = NewsFilter()
    df = df.drop_duplicates(subset=['content'], keep="last")
    df = df.drop_duplicates(subset=['title'], keep="last")

    # Pre processing of `Title`
    df      = df[~df['content'].isna()]
    titles  = df['title'].unique().tolist()   # 제목기준 필터링
    _titles = tokenClass.filter_title(titles) # 불필요한 제목 정보제거
    df      = df[~df['title'].isin(_titles)].reset_index(drop=True)
    _eng    = newsF.titles_of_eng(titles) # 외국어 기사 필터링
    df      = df[~df['title'].isin(_eng)]

    # Pre processing of `Content`
    df        = df.sort_values('datetime').reset_index(drop=True)
    df        = newsF.content_coding(df)    # 코딩내용 필터링
    contents  = df['content'].tolist()      # 본문내용 필터링
    _contents = []
    _infos    = newsF.contents_filter(contents)             # 필터링 연산을 위한 정보생성
    _contents += list(filter(lambda x : x[3]<110, _infos))  # -> 본문 길이가 너무 짧을 때 필터링
    _contents += list(filter(lambda x : (x[2]/x[3])>0.5, _infos)) # -> 외국어 비중 50% 이상일 때
    _contents = list(map(lambda x : x[0], _contents))
    _contents = list(set(_contents))

    if len(_contents) > 0:
        df = df[~df['content'].isin(_contents)]
        print(f"DataFrame Size : {df.shape[0]:,}")
        return df.sort_values('datetime').reset_index(drop=True)
    else:
        return None


# 빈도수 측정함수
@elapsed_time
def get_freq(df, min_count=3, multi_process=False, steps=1000):

    r"""Token 추출 및 빈도수 측정하기 
    df : 뉴스기사 원본 DataFrame
    min_count     : token 추출작업 기준
    multi_process : 추출기 동작시 multiprocessing 활용여부
    steps         : `multi_process` 작업시  batch size 크기
    """
    assert type(df) == pandas.DataFrame, "'df' only allowed DataFrame"
    tokenClass = Token()

    # 01 본문내용 문장단위로 나누기
    print("*"*5,f" Content split to Sentence ","*"*5)
    _lambda = lambda x : sent_tokenize(x)
    sents   = df['content'].tolist()
    sents   = df.content.to_list()
    sents   = list(map(_lambda, tqdm(sents))) # 기사본문 -> 문장단위 나누기
    sents   = tokenClass._flatten_list(sents)

    # 02 기사제목 덧붙이기
    _titles = tokenClass.filter_title(df.title.to_list())
    sents  += df[~df['title'].isin(_titles)]['title'].tolist()
    sents   = list(map(lambda x : x.strip(), sents))  # 여백제거
    sents   = list(filter(lambda x : len(x) < 170, sents)) # 너무 긴 문장들 제거
    # sents   = sorted(sents, key=len)                # 길이기준 정렬하기

    # 03 `sents` 문장들 내부 `token` 정제작업
    print("*"*5,f" Sentence to get Tokens ","*"*5)
    step_list = [
        " ".join(sents[steps*_ : steps*(1+_)])  
        for _ in range(int(len(sents)/steps)+1)
    ]
    print(f"Total Length : {len(step_list)}")

    if multi_process:
        process_count = int(multiprocessing.cpu_count()*0.6)
        with multiprocessing.Pool(processes=process_count) as pool:
            token_list = list(tqdm(pool.imap(tokenClass._tokenizer, step_list)))

    else:
        _lambda = lambda x : tokenClass._tokenizer(x)
        token_list = list(map(_lambda, tqdm(step_list)))

    token_list = Token()._flatten_list(token_list)
    idf = dict(Counter(token_list))
    idf = {
        k:v 
        for k, v in sorted(idf.items(),key=lambda x: x[1], reverse=True)  
        if ((v >= min_count) & (1<len(k)<20))
    }
    print(f"idf Tokens : {len(idf):,}")
    return idf


