from .base import *

def google_news_rss(query:str=None, country:str='ko'):
    r"""Google News Scraper (Ko,En)
    >> https://www.lobstr.io/blog/how-to-scrape-google-news-with-python"""

    query = query.replace(' ','%20')
    rss_url_ko = f'https://news.google.com/rss/search?q={query}&hl=ko&gl=KR' #&ceid=KR%3Ako'
    rss_url_en = f'https://news.google.com/rss/search?q={query}&hl=en-US' # &gl=US&ceid=US:en'

    if country.lower() == 'ko':   rss_url = rss_url_ko
    elif country.lower() == 'en': rss_url = rss_url_en
    else:                         rss_url = rss_url_en

    result_list = []
    rss_news = feedparser.parse(rss_url)
    for entry in rss_news.entries:
        title   = entry.title
        pubdate = entry.published          # 'Wed, 01 Feb 2023 08:00:00 GMT'
        pubdate = datetime.datetime.strptime(pubdate, "%a, %d %b %Y %H:%M:%S GMT").replace(tzinfo=None)
        # source  = entry.source.get('title')
        result_list.append([pubdate, title, ]) # , source])
    return result_list