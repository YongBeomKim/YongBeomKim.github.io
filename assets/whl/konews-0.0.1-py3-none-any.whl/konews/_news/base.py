import re
import sys
import pandas
import numpy
import time
import requests
import datetime
import feedparser
import multiprocessing
from tqdm import tqdm
from random import randint
from urllib import parse
from pytip import date_to_string
from lxml.html import fromstring, tostring
from ..__engine import Browser



# 크롤링 함수
class Crawler:

    r"""뉴스 수집기 공용함수"""
    web = Browser() # Multi Processing Selenium
    SESSION = None
    content_remove = [
        ('.', '. '),
        ('사진=게티이미지뱅크',' '),
        ("""/* iframe resize for nate news */\n(function($){\n\tsetYoutube();\n function setYoutube() {   if(typeof frmTarget !=\'undefined\'){ \tfrmTarget.find(\'iframe, object\').each(function (idx) { \t\t$(this).css({\'height\': parseInt($(this).width() / 1.8)}); \t\twindow.parent.postMessage({ \t\t\tmethod: \'fnct\', name: \'callFnct\', property: {target: \'youtube_resize_iframe\', elementClass: \'.frameMV\', height: parseInt($(this).width() / 1.8), idx: idx} \t\t}, \'*\'); \t});   } }\n}(jQuery));""", ''),
    ]
    # 본문에서 마지막 영역 필터링
    final_regex = [
        r"\/\*[ a-z\$;\'\*0-9 \\\/]+",  # '/* iframe resize for nate news */'
        '\/\* iframe resize for nate news \*\/',
        r'[\w]+@[\w]+[\w]+.[\w]+',      # e-mail 주소
        '^\*','^\◇','^\ⓒ','^\▲','^\▶','ⓒ','^\★',
        '^\→','^\ㆍ','^\-','^\■','\■$','^\☞','^(끝)',
        '^관련기사',
        '^저작권자(c)','^<저작권자(c)',
]

    # __init__(self, cate:str=None, date:str=None, page:str|list=None):
    def __init__(self, page:int|list=None):
        # self.cate = cate # 카테고리
        # self.date = date # 날짜
        self.page = page # 페이지

    # `url` => (selenium) => lxml.http 객체
    def _selenium(self, url):
        browser = self.web.browser
        browser.implicitly_wait(5)
        browser.get(url)
        response_lxml = fromstring(browser.page_source)
        browser.close()
        return response_lxml

    # `url` => (requests) => lxml.http 객체
    def _requests(self, url):
        response = self.web.requests(url)
        if response.status_code != 200:
            return None
        return response.text

    # requests 수집할 때 재활용 Session
    def _session(self):
        r"""https://wikidocs.net/13945 : hasattr() 변수내 맴버 확인"""
        if not self.session:
            self.session = requests.Session()
        return self.session

    # 크롤링 날짜 데이터 해석용
    ## `__함수명` 을 사용시 클래스 상속이 안되는 것에 주의
    def _to_datetime(self, text):
        r"""text -> datetime.str
        regex 추출값에 따라 `time regex format` 개별적용"""

        format = ''
        time_regex = {
            '[\d]{4}-[\d]{2}-[\d]{2}.[A-Z]{2}[\d]{1,2}:[\d]{1,2}:[\d]{1,2}':'%Y-%m-%d.%p%I:%M:%S',
            # '2022-07-31.AM3:02:30'
            '[\d]{4}\.[\d]{2}\.[\d]{2}\.[A-Z]{2}[\d]{1,2}:[\d]{1,2}':'%Y.%m.%d.%p%I:%M',
            # '2022.07.31.AM3:02'
            '[\d]{4}-[\d]{2}-[\d]{2} [\d]{1,2}:[\d]{1,2}':'%Y-%m-%d %H:%M', # '2024-02-27 01:36'
        }

        for regex, time_string in time_regex.items():
            check = re.findall(regex, text)
            if len(check) > 0:
                format = time_string

        # regex 분석결과 없을 때, 원본 그대로 출력
        if format == '':
            return text
        return datetime.datetime.strptime(text, format)

    # url 에서 page 숫자만 추출 (regex)
    def _url_to_page(self, url):
        r"""url 주소에서 `page` 숫자추출 및 출력하기"""
        PAGE = "".join(re.findall(r'&page=[\d]+', url)).replace('&page=','')
        return int(PAGE)

    # 목록 페이지 `PAGE_GAP`
    def _page_gap(self,
            url:str,
            response_lxml,
            xpath_numbers:str,
            xpath_next:str,
        ) -> int:
        r"""뉴스목록 페이지 크롤링
        : return : `마지막 페이지` - `현재 페이지`  cf> 연속값 존재시 -> 5"""

        # 중단조건 :: `다음` 표시가 없고, 마지막 페이지와 현재간격
        PAGE_GAP = 5
        CHECK    = True
        PAGE = "".join(re.findall(r'&page=[\d]+', url)).replace('&page=','')
        PAGE = int(PAGE)

        # Numbers, Next (`다음` 존재여부)
        try:
            numbers = ",".join(response_lxml.xpath(f'{xpath_numbers}'))
            numbers = [int(_)  for _ in numbers.split(',')   if len(re.findall(f"[\d]+", _)) > 0]
            # print(f"Numbers : {numbers}")
            next    = response_lxml.xpath(f'{xpath_next}')
            if '다음' not in next:
                PAGE_GAP = numbers[-1] - PAGE
            return CHECK, PAGE_GAP

        except Exception as E:
            print(f"{PAGE} has Exception : {E}")
            CHECK = False
            return CHECK, PAGE
