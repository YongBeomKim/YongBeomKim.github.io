from .base import *


class Nate(Crawler):

    r"""Nate 뉴스 가져오기
    : page : (str) 1개 페이지, (list) 다수 페이지
    : cate : 카테고리 `전체`, `정치`, `경제` ... 
    : merge_point : 줄단위 합칠 때 구분기호 default)` ` """

    merge_point   = " "
    url_head      = "https://news.nate.com/recent"
    xpath_next    = './/div[@id="newsContents"]/div[@class="paging"]'
    xpath_content = './/div[@id="newsContents"]//div[@class="mduSubjectList"]'
    email_regex   = r'[\w]+@[\w]+[\w]+.[\w]+'
    names = ["정치","경제","사회","국제","IT","스포츠","연예","칼럼"]
    codes = ["pol","eco","soc","int","its","spo","ent","col"]

    def __init__(self, cate, date=None, page=1):
        super().__init__(page=page)
        self.cate = cate # 카테고리
        self.date = date # 날짜

    @property
    def _category_dict(self):
        r"""news_code : {'정치': ['pol', 'n0101'], ...}"""
        return { _[0]: [list(_)[1]] + [f"n010{no+1}"]
            for no, _ in enumerate(zip(self.names, self.codes))}


    # ==========================
    # 01-1 뉴스목록 : `url` 생성함수
    @property
    def _get_urls(self) -> list:
        r"""뉴스목록 url 생성하기
        :: 단수, 복수 모두 list 로 출력"""
        if (type(self.page) == int) | (type(self.page) == str):
            self.page = [int(self.page)]

        category_dict = self._category_dict
        assert self.cate in self.names, f'{self.cate} not in {self.names}'
        self.date   = date_to_string(self.date)
        date_string = "".join(re.findall(r'[\d]+', self.date))

        result = []
        for page in self.page:
            query = {
                "type":"c",
                "cate":category_dict[self.cate][0],
                "mid":category_dict[self.cate][1],
                "date":date_string,
                "page":page,
            }
            query = parse.urlencode(query, encoding='UTF-8', doseq=True)
            result.append(f"{self.url_head}?{query}")
        return sorted(result)

    # 01-2 뉴스목록 : `본문`
    def _get_list(self, url) -> int | pandas.DataFrame:

        r"""최신뉴스 목록 수집기
        : response_lxml : 페이지 lxml 변환객체 """

        PAGE = self._url_to_page(url)
        response = self._requests(url)
        if response is None:
            return PAGE

        # Pagination 에서 `다음` 문자와 `페이지 숫자` 추출
        response_lxml = fromstring(response)
        xpath_numbers = f'{self.xpath_next}/span[@class="page"]/a/text()'
        xpath_next    = f'{self.xpath_next}/a[@class="next"]/img/@alt'
        CHECK, PAGE_GAP = self._page_gap(url, response_lxml, xpath_numbers, xpath_next)
        # print(f"Check :{CHECK}\n Page Gap : {PAGE_GAP}")
        PAGE_GAP      += 1  # 해당 페이지는 수집되지 않아 +1 추가하기
        if CHECK == False:
            return PAGE # 오류를 출력한 Page

        if PAGE_GAP < 0:    # None 을 출력하거나 음수일 때 중단
            return PAGE

        result = []
        items  = response_lxml.xpath(self.xpath_content)
        for item in items:
            try:
                link      = "https:" + item.xpath('.//a[@class="lt1"]')[0].get('href')
                thumb_img = item.xpath('.//span[@class="ib"]//img/@src')
                title     = item.xpath('.//span[@class="tb"]/h2//text()')[0]
                summary   = item.xpath('.//span[@class="tb"]//text()')[-1].strip()
                press     = item.xpath('.//span[@class="medium"]//text()')[0].strip()
                out_time  = item.xpath('.//span[@class="medium"]/em/text()')[0].strip()
                if len(thumb_img) > 0:
                    thumb_img = f"https:{thumb_img[0]}"
                else:
                    thumb_img = None
                result.append([link, title, summary, press, out_time, thumb_img])

            except Exception as E:
                print(E)

        if len(result) == 0:
            return PAGE

        df = pandas.DataFrame(result)
        df.columns = ['url','title','summary','press','datetime','photo']
        df['section'] = self.cate
        return df

    # 01-3 Nate News 목록 수집기
    def get_list(self, multi:bool=False, worker:int=1) -> list | pandas.DataFrame:

        r"""다음 뉴스목록 수집기
        : return : PAGE_GAP, pandas.DataFrame(결과값) """

        urls  = self._get_urls
        LOOP  = True
        items = []

        if multi:
            with multiprocessing.Pool(processes=worker) as pool:
                items = list(
                    tqdm(pool.imap(self._get_list, urls),
                    total=len(urls))
                )
            errors = [_  for _ in items   if type(_) == int]
            errors = [_  for _ in errors  if _ > 0]

        else:
            for _ in tqdm(urls):
                item = self._get_list(_)
                if type(item) == int:
                    break
                items.append(item)

            pages = [self._url_to_page(_)  for _ in urls]
            errors = set(pages) - set(pages[:len(items)])
            errors = sorted(errors)


        items  = [_  for _ in items   if type(_) != int]
        items  = [_  for _ in items   if _ is not None]
        if len(items) > 0:
            df = pandas.concat(items, axis=0
                ).drop_duplicates(subset=['url']
                ).reset_index(drop=True)

            _year  = date_to_string(self.date, datetime_obj=True).year
            _times = [f"{str(_year)}-{_}"    for _ in df['datetime']]
            _times = [self._to_datetime(_)   for _ in _times]
            df['datetime'] = _times
        else:
            df = None
        return sorted(errors), df


    # ==========================
    # 02-1 Crawler of 개별뉴스
    def _get_content(self, url):
        r""" 뉴스기사 Content 페이지에서 상세정보 크롤링 (가장 오류가 많이 발생)
        출고시간, 기자, 본문 : to list"""
        response      = self._requests(url=url)
        response_lxml = fromstring(response)

        try:
            content   = response_lxml.xpath('.//div[@id="articleView"]')[0] # articleContetns
            content   = response_lxml.xpath('.//div[@id="articleView"]')[0] # 
            news_link = content.xpath('.//span[@class="link"]/a[@class="articleOriginal"]')
            if len(news_link) > 0:
                news_link = news_link[0].get('href')
            else:
                news_link = ''

            # 본문 수집기
            texts_raw = content.xpath('.//div[@id="realArtcContents"]//text()')
            texts = [_.strip()  for _ in texts_raw  if len(_.strip())>0]

            # `_index_except` 하단찾기 제외할 인덱스
            # `email` 주소로 찾기 & `사진` 과 관련된 내용은 제외
            author        = ''
            email_regex   = r'[\w]+@[\w]+[\w]+.[\w]+'
            _lambda       = lambda x : re.findall(email_regex, x)
            _regex_find   = [_  for _ in list(map(_lambda, texts))] # 조건 True 객체
            _index_except = [no for no,_ in enumerate(_regex_find)  if len(_) > 0]
            _index_except = [_  for _ in _index_except     if texts[_].find('사진') == -1] # 사진 이메일은 제외
            if len(_index_except) > 0:
                author = texts[_index_except[-1]][:40] # 작성자 이메일 추출

            # 정규식 활용한 본문 중 마지막 Line 찾기
            result = []
            for no, text in enumerate(texts):
                _lambda = lambda x : re.findall(x, text)
                _check  = list(map(_lambda, self.final_regex))
                _check  = [_  for _ in _check  if len(_) > 0] # 검색결과
                if len(_check):
                    result.append(no)

            ## 마지막 찾기 Line index
            _index_list = set(result +_index_except)
            _index_list = sorted(list(_index_list))
            _index_list = [_  for _ in sorted(_index_list)  if _>1]

            # 마지막 라인 예제 중 가장 긴 내용 수집하기
            # 분석은 30% 을 대상으로 tf 연산하기 (뒷부분은 날리기 ...)
            if len(_index_list) > 0:
                texts = texts[:_index_list[-1]]
                # texts = texts[:_index_list[0]]

            # 전체내용 합치기
            # <br/> 을 활용히여, 합친부분 Deep Learning 으로 재정의 하기 (idf)
            # content = "<br/>".join(texts)
            # content = " ".join(texts)
            content = self.merge_point.join(texts)
            return [author, content, url, news_link]

        except Exception as E:
            print(f"{url} has Error of {E}")
        return None

    # 02-2 Nate 개별뉴스
    def get_content(self, urls, multi=False, worker=1) -> pandas.DataFrame:
        r"""`__get_content` 본문 수집기
        cf) time.sleep(0.5 + randint(1,10) / 3)
        tip : 사용자가 입력 `batch size` 를 특정, 중단 Point 지정 및 분할하기"""
        if multi:
            with multiprocessing.Pool(processes=worker) as pool:
                result = list(
                    tqdm(pool.imap(self._get_content, urls),
                    total=len(urls))
                )
        else:
            result = [self._get_content(_) for _ in tqdm(urls)]

        column_list = ['author','content','url','url_news']
        result      = [_  for _ in result  if _ is not None]
        if len(result) > 0:
            return pandas.DataFrame(result, columns=column_list)
        return None
