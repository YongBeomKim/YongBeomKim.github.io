from .base import *


# Naver 뉴스 가져오기
class Naver(Crawler):

    r"""Naver 뉴스 가져오기
    : page : (str) 1개 페이지, (list) 다수 페이지 
    : cate : 카테고리 `전체`, `정치`, `경제` ... """

    list_type  = 'summary' # 'paper'
    url_header = "https://news.naver.com/main/list.naver"
    xpath_next = ".//div[@id='main_content']/div[@class='paging']/a"
    side_dict  = {
        '전체':1, "정치":100, "경제":101, 
        "사회":102, "생활문화":103, "세계":104, 
        "IT과학":105, "오피니언":110, "연합뉴스":140,
    }

    def __init__(self, cate, date=None, page=1):
        super().__init__(page=page)
        self.cate = cate # 카테고리
        self.date = date # 날짜

    def get_url(self) -> list:  

        r"""뉴스목록 url 생성하기
        :: 단수, 복수 모두 list 로 출력"""
        if (type(self.page) == int) | (type(self.page) == str):
            self.page = [int(self.page)]

        # 날짜입력 : 20240101
        self.date   = date_to_string(self.date)
        date_string = "".join(re.findall(r'[\d]+', self.date))

        result = []
        assert self.cate in list(self.side_dict.keys()),\
            f"`{self.cate}` not in `{self.side_dict.keys()}`"

        _side  = self.side_dict.get(self.cate)
        for page in self.page:
            query = {
                "listType":"summary",
                "sid1":f"{_side:03d}",
                "date":date_string,
                "page":page
            }

            # 연합뉴스인 경우 Query Set 내용 추가
            if _side == 140:
                query_add = {
                    "sid1":"001",
                    "sid2":140,
                    "oid":"001",
                }
                query.update(query_add)
                del query['listType']

            query = parse.urlencode(query, encoding='UTF-8', doseq=True)
            result.append(f"{self.url_header}?{query}")
        return result


    def get_page_source(self, urls:list) -> list:

        r"""urls 목록에 따라 수집기 작동
        : urls : 페이지 순서대로 정렬
        -> `lxml.html` 변환객체"""
        web     = Browser()
        browser = web.browser
        urls    = sorted(urls)

        # 중단조건 :: `다음` 표시가 없고, 마지막 페이지와 현재간격 
        PAGE_GAP = 5
        result  = []
        for url in urls:
            PAGE = "".join(re.findall(r'&page=[\d]+', url)).replace('&page=','')
            PAGE = int(PAGE)

            # Progress Bar (add Page)
            sys.stdout.write("\r%d Page" % PAGE)
            sys.stdout.flush()

            browser.implicitly_wait(5)
            browser.get(url) 
            response_lxml = fromstring(browser.page_source)
            result.append(response_lxml)

            # Pagination 에서 `다음` 문자와 `페이지 숫자` 추출
            numbers = ",".join(response_lxml.xpath(f"{self.xpath_next}//text()"))
            numbers = [int(_)  for _ in numbers.split(',')   if len(re.findall(f"[\d]+", _)) > 0]
            xpath_next = f"{self.xpath_next}[contains(@class,'next')]//text()"
            next = response_lxml.xpath(xpath_next)

            # Break Time
            if PAGE % 7 == 3:
                time.sleep(0.5 + randint(1,3) / 3)

            # Loop break condition
            if '다음' not in next:
                PAGE_GAP = numbers[-1] - PAGE
                if PAGE_GAP <= 0:
                    break

        # Progress Bar (finished)
        sys.stdout.write("\r%d Page" % PAGE)
        sys.stdout.write("\n")
        return result


    def __get_list(self, response) -> pandas.DataFrame:
        r"""lxml 객체서 필요한 정보 -> Pandas.DataFrame"""
        # 크롤링 : 본문내용
        result = []
        items = response.xpath("//div[contains(@class,'list_body')]/ul/li")

        for no, item in enumerate(items):
            try:
                list_temp = []
                # 뉴스 Title 크롤링 (사진이 있을 때, 없을 때)
                if len(item.xpath('.//a'))==1:
                    title = item.xpath('.//a')[0].text_content().strip()
                else : 
                    title = item.xpath('.//a')[-1].text_content().strip()
                list_temp.append(title)

                # 공통적으로 날짜정보 포함필드
                date_summary = "".join(item.xpath(".//span[contains(@class,'date')]/text()")).strip()
                list_temp.append(date_summary)

                # 신문 지면정보
                paper = "".join(item.xpath(f'.//span[@class="newspaper_info"]//text()')).strip() 
                list_temp.append(paper)

                # 제목과 신문
                list_temp += [
                    "".join(item.xpath(f'.//span[@class="{class_text}"]/text()')).strip()  
                    for class_text in ['writing', "lede"]
                ]
                list_temp.append(item.xpath('.//a')[0].get('href')) # link
                result.append(list_temp)

            except Exception as E:
                print(E)

        if len(result) == 0:
            return None

        df         = pandas.DataFrame(result)
        df.columns = ['title','datetime','page','press','summary','url']
        number_id  = ["".join(re.findall('[\d]+', _))  for _ in df['url']]
        df.insert(0, 'idxno', number_id)
        return df


    def get_list(self):
        r"""네이버 뉴스목록 수집기"""
        urls  = self.get_url()
        items = self.get_page_source(urls)
        items = [self.__get_list(_) for _ in items]
        return pandas.concat(items, axis=0).reset_index(drop=True)


    def __get_content(self, url, raw=False):
        r""" 뉴스기사 Content 페이지에서 상세정보 크롤링 (가장 오류가 많이 발생)
        출고시간, 기자, 본문 : to list"""

        try:
            browser  = Browser()
            response = browser.requests(url).text
        except Exception as E:
            print(E) 
            return None

        if raw:
            return response

        response_lxml = fromstring(response)
        name_xpath    = "//div[@class='byline']//text()"
        content_xpath = "//div[@id='newsct_article']//text()"
        time_xpath    = ".//div[@class='media_end_head_info_datestamp_bunch']/span//text()"
        name          = "".join([text.strip() for text in response_lxml.xpath(name_xpath)])
        content       = "".join([text.strip() for text in response_lxml.xpath(content_xpath)])
        time          = " | ".join(response_lxml.xpath(time_xpath))
        time          = time.replace('오전','AM').replace('오후','PM')
        time          = time.split("|")[0].strip().replace(' ','')

        url_news_xpath= ".//a[@class='media_end_head_origin_link']/@href"
        url_news      = "".join([text.strip() for text in response_lxml.xpath(url_news_xpath)])
        return [url, time ,name[:300], content, url_news]


    def get_content(self, urls):

        r"""뉴스본문 수집기"""
        assert type(urls) == list, "`urls` is not list"

        # Crawling ...
        result = []
        for no, url in tqdm(enumerate(urls)):
            try:
                result.append(self.__get_content(url))
            except Exception as E:
                print(E)
            if no % 11 == 6:
                time.sleep(0.5 + randint(1,3) / 3)
            if no % 27 == 16:
                time.sleep(1 + randint(1,10) / 3)

        if len(result) == 0:
            return None

        # Python Pandas:  datetimes
        ## https://stackoverflow.com/questions/64667615/python-pandas-interpolate-datetimes
        column_list = ['url', 'datetime', 'author', 'content', 'url_news']
        result      = [_  for _ in result                if _ is not None]
        df = pandas.DataFrame(result, columns=column_list)
        df['datetime'] = df['datetime'].map(lambda x : self._to_datetime(x))

        # pandas: Interpolate NaN with interpolate()
        ## https://note.nkmk.me/en/python-pandas-interpolate/
        if df['datetime'].isna().sum() != 0:
            if len(df) == 1:
                _date = date_to_string(self.date, datetime_obj=True)
                df['datetime'] = datetime.combine(_date, datetime.min.time())
            else:
                times = pandas.Series(df['datetime'].values.astype(float))
                times[times<0] = numpy.NaN      # Interpolate 를 위해 NaT 를 NaN 으로 변환
                df['datetime'] = pandas.to_datetime(times.interpolate(limit_direction='both'))
        return df
