from .base import *


class TheBell(Crawler):

    url  = "https://www.thebell.co.kr/free/content/"
    xpath_list = './/div[@id="contents"]//div[@class="listBox"]/ul/li'

    def __init__(self, date=None, page=1):
        super().__init__(page=page)
        self.date = date # 날짜

    def _url_simple(self, url):
        url_head = url.split('?')[0]
        query_string = parse.urlparse(url).query
        data = dict(parse.parse_qsl(parse.urlsplit(query_string).path))
        return f"{url_head}?key={data['key']}"

    # ==========================
    # 01-1 뉴스목록 : `url` 생성함수
    @property
    def _get_urls(self) -> list:
        r"""목록 수집대상 url 추출"""
        # PreProcessing
        ## page -> List[pages]
        self.date   = date_to_string(self.date)
        if (type(self.page) == int) | (type(self.page) == str):
            self.page = [int(self.page)]

        result = []
        for page in self.page:
            query = {
                "svccode":"00",
                "page":page,
            }
            query = parse.urlencode(query, encoding='UTF-8', doseq=True)
            result.append(f"{self.url}article.asp?{query}")
        return sorted(result)

    # 01-2 뉴스목록 : `본문`
    def _get_list(self, url) -> int | pandas.DataFrame:

        r"""최신뉴스 목록 수집기
        : response_lxml : 페이지 lxml 변환객체 """
        PAGE = self._url_to_page(url)
        response = self._requests(url)
        if response is None:
            return PAGE

        result = []
        response_lxml = fromstring(response)
        items  = response_lxml.xpath(self.xpath_list)

        for item in items:
            try:
                link_url = item.xpath('.//a')[0].get('href')
                link_url = self.url + link_url
                title    = item.xpath('.//dt/text()')[0]
                content  = item.xpath('.//dd/text()')[0]
                infos = [_.strip()  for _ in item.xpath('.//dd/span//text()')]
                for _tokens in [('\xa0', ' '),('오전','.AM'),('오후','.PM')]:
                    infos = [_.replace(_tokens[0], _tokens[1]) for _ in infos]
                _name, _time = infos
                result.append([title, content, _time.replace(' ',''), _name, link_url])

            except Exception as E:
                print(E)

        column_list = ['title', 'summary', 'datetime', 'author', 'url']
        df = pandas.DataFrame(result, columns=column_list)
        df['url'] = list(map(lambda x : self._url_simple(x), df['url'].tolist()))
        df['datetime'] = list(map(lambda x : self._to_datetime(x), df['datetime'].tolist()))
        df.insert(0, 'press', '더벨')
        df = df.loc[:, ['datetime', 'title', 'summary', 'press','author', 'url']] # 'idxno']]
        return df

    # 01-3 News 목록 수집기
    def get_list(self, multi:bool=False, worker:int=1):

        r"""다음 뉴스목록 수집기
        : return : PAGE_GAP, pandas.DataFrame(결과값) """

        urls  = self._get_urls
        LOOP  = True
        items = []

        if multi:
            with multiprocessing.Pool(processes=worker) as pool:
                items = list(
                    tqdm(pool.imap(self._get_list, urls),
                    total=len(urls))
                )
            errors = [_  for _ in items   if type(_) == int]
            errors = [_  for _ in errors  if _ > 0]

        else:
            for _ in tqdm(urls):
                item = self._get_list(_)
                if type(item) == int:
                    break
                items.append(item)

            pages = [self._url_to_page(_)  for _ in urls]
            errors = set(pages) - set(pages[:len(items)])
            errors = sorted(errors)

        items  = [_  for _ in items   if type(_) != int]
        items  = [_  for _ in items   if _ is not None]
        if len(items) > 0:
            df = pandas.concat(items, axis=0
                ).drop_duplicates(subset=['url']
                ).reset_index(drop=True)
            df['section'] = "경제"
        else:
            df = None
        return sorted(errors), df


    # ==========================
    # 02-1 Crawler of 개별뉴스
    def _get_content(self, url, raw=False):
        r"""`_get_content` 의 전체기사 목록 크롤링
        : page (int) : 전체기사 목록 페이지
        : raw (bool) : 수집결과 출력형태 """
        response      = self._requests(url=url)
        response_lxml = fromstring(response)
        if raw:
            return response
        try:
            # 출력날짜
            datetime_string = "".join(response_lxml.xpath('.//p[@class="tip mgb20"]//text()'))
            datetime_string = ".".join(re.findall('[0-9:]+', datetime_string))

            # 본문 필터링
            content   = "".join(response_lxml.xpath(".//div[@id='article_main']//text()")).strip()
            tap_space = re.findall('[\t\n\r]+', content)
            for _ in list(set(tap_space)):
                content = content.replace(_, ' ')

            # 삽입된 이미지 목록 필터링
            images = [_.get('src')  for _ in response_lxml.xpath(".//div[@id='article_main']//img")]
            images = [_  for _ in images  if _.find('news/photo/') != -1]
            images = ",".join(images)
            return [url, datetime_string, content, images]

        except Exception as E:
            print(f"{url} has Error of {E}")
        return None

    # 02-2 개별뉴스 수집기
    def get_content(self, urls, multi=False, worker=1) -> pandas.DataFrame:
        r"""`__get_content` 본문 수집기
        cf) time.sleep(0.5 + randint(1,10) / 3)
        tip : 사용자가 입력 `batch size` 를 특정, 중단 Point 지정 및 분할하기"""
        if multi:
            with multiprocessing.Pool(processes=worker) as pool:
                result = list(
                    tqdm(pool.imap(self._get_content, urls),
                    total=len(urls))
                )
        else:
            result = [self._get_content(_) for _ in tqdm(urls)]

        result      = [_  for _ in result  if _ is not None]
        column_list = ['url', 'datetime', 'content', 'photo']
        if len(result) > 0:
            df = pandas.DataFrame(result, columns=column_list)
            df = df.loc[:, ['url', 'content', 'photo']]
            df['url_news'] = df['url']
            return df
        return None
