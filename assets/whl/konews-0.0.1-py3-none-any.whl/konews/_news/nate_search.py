from .base import *


class NateSearch(Crawler):
    r"""Nate 뉴스에서 검색결과 확인하기"""

    # xpath_next = './/div[@id="newsContents"]/div[@class="paging"]'
    url_head = "https://news.nate.com/search"
    merge_point   = " "
    xpath_content = './/div[@class="search-result"]/ul/li'
    email_regex   = r'[\w]+@[\w]+[\w]+.[\w]+'

    def __init__(self, start=None, end:str=None, 
            page=1, token:str=None):
        super().__init__(page=page)
        self.token = token
        self.start = start
        self.end   = end

    # ==========================
    # 01-1 뉴스목록 : `url` 생성함수
    @property
    def _get_urls(self) -> list:
        r"""뉴스목록 url 생성하기
        :: 단수, 복수 모두 list 로 출력"""
        if (type(self.page) == int) | (type(self.page) == str):
            self.page = [int(self.page)]

        self.start = date_to_string(self.start).replace('-','')
        self.end   = date_to_string(self.end).replace('-','')

        result = []
        for page in self.page:
            query = {
                "q":self.token,
                "ps":"3",
                "ps1":self.start, # start
                "ps2":self.end, # end
                "o":"T",
                "page":page,
            }
            query = parse.urlencode(query, encoding='UTF-8', doseq=True)
            result.append(f"{self.url_head}?{query}")
        return sorted(result)


    # 01-2 뉴스목록 : `본문`
    def _get_list(self, url) -> int | pandas.DataFrame:

        r"""최신뉴스 목록 수집기
        : response_lxml : 페이지 lxml 변환객체 """

        response = self._requests(url)
        # Pagination 에서 `다음` 문자와 `페이지 숫자` 추출
        response_lxml = fromstring(response)
        # return response_lxml
        # print(url)

        result = []
        items  = response_lxml.xpath(self.xpath_content)
        for item in items:
            try:
                link      = "https:" + item.xpath('.//a[@class="thumb-wrap"]')[0].get('href')
                thumb_img = item.xpath('.//img/@src')
                title     = item.xpath('.//span[@class="tit"]/h2//text()')[0]
                summary   = item.xpath('.//span[@class="txt"]//text()')[-1].strip()
                press     = item.xpath('.//span[@class="time"]/text()')[0].strip()
                out_time  = item.xpath('.//span[@class="time"]//text()')[0].strip()
                if len(thumb_img) > 0:
                    thumb_img = f"https:{thumb_img[0]}"
                else:
                    thumb_img = None
                result.append([link, title, summary, press, out_time, thumb_img])

            except Exception as E:
                print(E)

        if len(result) == 0:
            return None
        return result
        df = pandas.DataFrame(result)
        df.columns = ['url','title','summary','press','datetime','photo']
        return df

    # 01-3 Nate News 목록 수집기
    def get_list(self, multi:bool=False, worker:int=1) -> list | pandas.DataFrame:

        r"""다음 뉴스목록 수집기
        : return : PAGE_GAP, pandas.DataFrame(결과값) """

        urls  = self._get_urls
        LOOP  = True
        items = []

        if multi:
            with multiprocessing.Pool(processes=worker) as pool:
                items = list(
                    tqdm(pool.imap(self._get_list, urls),
                    total=len(urls))
                )
            errors = [_  for _ in items   if type(_) == int]
            errors = [_  for _ in errors  if _ > 0]

        else:
            items = [self._get_list(_)  for _ in tqdm(urls)]
        return items
        #         item = self._get_list(_)
        #         if type(item) == int:
        #             break
        #         items.append(item)

        #     pages = [self._url_to_page(_)  for _ in urls]
        #     errors = set(pages) - set(pages[:len(items)])
        #     errors = sorted(errors)


        # items  = [_  for _ in items   if type(_) != int]
        # items  = [_  for _ in items   if _ is not None]
        # if len(items) > 0:
        #     df = pandas.concat(items, axis=0
        #         ).drop_duplicates(subset=['url']
        #         ).reset_index(drop=True)

        #     _year  = date_to_string(self.date, datetime_obj=True).year
        #     _times = [f"{str(_year)}-{_}"    for _ in df['datetime']]
        #     _times = [self._to_datetime(_)   for _ in _times]
        #     df['datetime'] = _times
        # else:
        #     df = None
        # return sorted(errors), df

